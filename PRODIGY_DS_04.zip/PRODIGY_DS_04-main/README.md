# PRODIGY_DS_04
Analyze and visualize sentiment patterns in social media data to understand public opinion and attitudes towards specific topics or brands.
